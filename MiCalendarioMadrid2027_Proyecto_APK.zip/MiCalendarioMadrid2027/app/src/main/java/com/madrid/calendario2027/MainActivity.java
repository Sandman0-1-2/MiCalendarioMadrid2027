package com.madrid.calendario2027;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.util.Locale;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int PURPLE = Color.rgb(111,63,181);
    private static final int DEEP = Color.rgb(76,38,127);
    private static final int PALE = Color.rgb(242,235,251);
    private static final int RED = Color.rgb(190,52,77);
    private static final int INK = Color.rgb(41,36,58);
    private static final int MUTED = Color.rgb(119,113,132);
    private static final String[] MONTHS = {"enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"};
    private static final String[] WEEKDAYS = {"L","M","X","J","V","S","D"};
    private final Map<String,String> holidays = new HashMap<>();
    private SharedPreferences prefs;
    private int month = 0;
    private LinearLayout root, header;
    private TextView monthTitle;
    private GridLayout grid;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(DEEP);
        getWindow().setNavigationBarColor(DEEP);
        prefs = getSharedPreferences("calendar_notes", MODE_PRIVATE);
        initHolidays();
        buildScreen();
        renderCalendar();
    }

    private void initHolidays() {
        holidays.put("2027-01-01", "Año Nuevo"); holidays.put("2027-01-06", "Reyes");
        holidays.put("2027-03-19", "San José"); holidays.put("2027-03-25", "Jueves Santo"); holidays.put("2027-03-26", "Viernes Santo");
        holidays.put("2027-05-01", "Fiesta del Trabajo"); holidays.put("2027-05-15", "San Isidro (local)");
        holidays.put("2027-08-16", "Asunción (traslado previsto)"); holidays.put("2027-10-12", "Fiesta Nacional");
        holidays.put("2027-11-01", "Todos los Santos"); holidays.put("2027-11-09", "Almudena (local)");
        holidays.put("2027-12-06", "Constitución"); holidays.put("2027-12-08", "Inmaculada"); holidays.put("2027-12-25", "Navidad");
    }

    private void buildScreen() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(20),dp(20),dp(20),dp(18)); header.setBackground(roundGradient(PURPLE, DEEP, 24));
        TextView eyebrow = text("AGENDA PERSONAL", 12, Color.rgb(231,218,250), true); eyebrow.setLetterSpacing(.12f); header.addView(eyebrow);
        TextView title = text("Mi calendario", 29, Color.WHITE, true); LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,-2); tp.topMargin=dp(4); header.addView(title,tp);
        TextView subtitle = text("Madrid · Comunidad de Madrid · 2027", 13, Color.rgb(238,230,249), false); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(2); header.addView(subtitle,sp);
        LinearLayout monthBar = new LinearLayout(this); monthBar.setGravity(Gravity.CENTER_VERTICAL); monthBar.setOrientation(LinearLayout.HORIZONTAL); LinearLayout.LayoutParams mbp = new LinearLayout.LayoutParams(-1,-2); mbp.topMargin=dp(17); header.addView(monthBar,mbp);
        monthTitle = text("enero 2027", 22, Color.WHITE, true); monthBar.addView(monthTitle,new LinearLayout.LayoutParams(0,-2,1));
        Button prev = navButton("‹"); monthBar.addView(prev); prev.setOnClickListener(v->{month=(month+11)%12;renderCalendar();});
        Button next = navButton("›"); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(dp(42),dp(42)); np.leftMargin=dp(7); monthBar.addView(next,np); next.setOnClickListener(v->{month=(month+1)%12;renderCalendar();});
        root.addView(header);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(12),dp(16),dp(12),dp(22)); scroll.addView(content);
        LinearLayout legend = new LinearLayout(this); legend.setGravity(Gravity.CENTER_VERTICAL); TextView l1=text("● Festivo previsto",12,RED,true); legend.addView(l1); TextView l2=text("   ● Día con nota",12,PURPLE,true); legend.addView(l2); content.addView(legend);
        grid = new GridLayout(this); grid.setColumnCount(7); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,-2); gp.topMargin=dp(10); content.addView(grid,gp);
        TextView caution = text("Los festivos de 2027 son orientativos y deben confirmarse con el calendario oficial autonómico y local cuando se publique.",11,MUTED,false); caution.setPadding(dp(4),dp(15),dp(4),dp(8)); content.addView(caution);
        Button home = new Button(this); home.setText("Volver a enero"); home.setTextColor(DEEP); home.setAllCaps(false); content.addView(home); home.setOnClickListener(v->{month=0;renderCalendar();});
        setContentView(root);
    }

    private void renderCalendar() {
        monthTitle.setText(MONTHS[month]+" 2027"); grid.removeAllViews();
        for(String day:WEEKDAYS){TextView w=text(day,12,MUTED,true);w.setGravity(Gravity.CENTER);GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=dp(32);p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(w,p);}
        Calendar c=Calendar.getInstance(); c.clear(); c.set(2027,month,1); int offset=(c.get(Calendar.DAY_OF_WEEK)+5)%7; int count=c.getActualMaximum(Calendar.DAY_OF_MONTH);
        for(int i=0;i<offset;i++) addBlank();
        for(int d=1;d<=count;d++) addDay(d);
        int total=offset+count; int trailing=(7-total%7)%7; for(int i=0;i<trailing;i++) addBlank();
    }

    private void addBlank(){TextView blank=new TextView(this);GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=dp(72);p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(dp(2),dp(2),dp(2),dp(2));grid.addView(blank,p);}
    private void addDay(int d){
        String key=String.format(Locale.US,"2027-%02d-%02d",month+1,d); String holiday=holidays.get(key); String saved=prefs.getString(key,"");
        LinearLayout cell=new LinearLayout(this);cell.setOrientation(LinearLayout.VERTICAL);cell.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);cell.setPadding(dp(2),dp(5),dp(2),dp(2));
        int bg= !saved.isEmpty()?Color.rgb(248,243,255):(holiday!=null?Color.rgb(255,244,246):Color.WHITE);
        GradientDrawable shape=round(bg,holiday!=null?Color.rgb(242,201,210):(saved.isEmpty()?Color.rgb(233,228,239):Color.rgb(214,196,240))); shape.setStroke(dp(1),holiday!=null?Color.rgb(242,201,210):(saved.isEmpty()?Color.rgb(233,228,239):Color.rgb(214,196,240)));cell.setBackground(shape);
        TextView num=text(String.valueOf(d),15,holiday!=null?RED:(saved.isEmpty()?INK:DEEP),true);num.setGravity(Gravity.CENTER);cell.addView(num,new LinearLayout.LayoutParams(-1,-2));
        if(holiday!=null){TextView h=text(holiday,8,RED,false);h.setGravity(Gravity.CENTER);h.setMaxLines(3);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(3);cell.addView(h,hp);}
        if(!saved.isEmpty()){TextView n=text("● Nota",8,PURPLE,true);n.setGravity(Gravity.CENTER);cell.addView(n);}
        cell.setOnClickListener(v->editNote(d,key,holiday));GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=dp(72);p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(dp(2),dp(2),dp(2),dp(2));grid.addView(cell,p);
    }

    private void editNote(int day,String key,String holiday){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(8),dp(20),0);
        TextView h=text(holiday==null?"Día normal":"Festivo: "+holiday,13,holiday==null?MUTED:RED,true);box.addView(h);
        EditText input=new EditText(this);input.setHint("Escribe una cita, turno o recordatorio…");input.setGravity(Gravity.TOP|Gravity.START);input.setMinLines(4);input.setMaxLines(7);input.setText(prefs.getString(key,""));box.addView(input);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(day+" de "+MONTHS[month]+" de 2027").setView(box).setNegativeButton("Cancelar",null).setNeutralButton("Borrar nota",(di,which)->{prefs.edit().remove(key).apply();renderCalendar();}).setPositiveButton("Guardar",(di,which)->{String value=input.getText().toString().trim();if(value.isEmpty())prefs.edit().remove(key).apply();else prefs.edit().putString(key,value).apply();renderCalendar();Toast.makeText(this,"Nota guardada",Toast.LENGTH_SHORT).show();}).create();dialog.show();
    }
    private Button navButton(String label){Button b=new Button(this);b.setText(label);b.setTextSize(25);b.setPadding(0,0,0,dp(3));b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(round(Color.rgb(129,86,190),Color.rgb(170,140,211)));b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(0);b.setMinimumHeight(0);b.setLayoutParams(new LinearLayout.LayoutParams(dp(42),dp(42)));return b;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable round(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(10));d.setStroke(dp(1),stroke);return d;}
    private GradientDrawable roundGradient(int a,int b,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});d.setCornerRadius(dp(radius));return d;}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
